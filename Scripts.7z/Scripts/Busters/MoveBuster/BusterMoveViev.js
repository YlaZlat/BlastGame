const BusterProtoViev = require('BusterProtoViev');

cc.Class({
    extends: BusterProtoViev ,

    properties: {

        costLabel: {
            default: null,
            type: cc.Label,
            override: true
        },

    },


});
